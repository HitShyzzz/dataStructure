create
    definer = root@localhost procedure pro_insert()
begin
 declare i int default 1;
 while i<=1000000 do
  insert into dept values(i,'开发部','db01');
  set i=i+1;
 end while;
end;

